#include <stdio.h>
#include <stdint.h>

#include "../filter.h"

int main(void)
{
    filter flt(8);
    uint16_t val;

    flt.init();
    while (scanf("%hu\n", &val) > 0) {
        flt.addReading(val);
        printf("%hu %hu\n", val, flt.get());
    }
    return 0;
}
