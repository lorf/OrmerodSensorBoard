#include <stdio.h>
#include <stdint.h>

//Low pass chebyshev filter order=1 alpha1=0.1 
class filter
{
    public:
        filter()
        {
            v[0]=0;
            v[1]=0;
        }
    private:
        short v[2];
    public:
        short step(short x)
        {
            v[0] = v[1];
            long tmp = ((((x * 515222L) >>  3)  //= (   2.4567704618e-1 * x)
                + ((v[0] * 266677L) >> 1)   //+(  0.5086459076*v[0])
                )+131072) >> 18; // round and downshift fixed point /262144

            v[1]= (short)tmp;
            return (short)((
                 (v[0] + v[1]))); // 2^
        }
};






int main(void)
{
    filter flt;
    uint16_t val;

    while (scanf("%hu\n", &val) > 0)
        printf("%hu %hu\n", val, flt.step(val));
    return 0;
}
