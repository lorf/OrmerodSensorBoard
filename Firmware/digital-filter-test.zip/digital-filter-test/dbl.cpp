//Low pass chebyshev filter order=2 alpha1=0.02 
class  FilterChLp2
{
    public:
        FilterChLp2()
        {
            v[0]=0.0;
            v[1]=0.0;
        }
    private:
        double v[3];
    public:
        double step(double x) //class II 
        {
            v[0] = v[1];
            v[1] = v[2];
            v[2] = (2.685741670189673025e-3 * x)
                 + (-0.92222621290283768314 * v[0])
                 + (1.91148324622207899104 * v[1]);
            return 
                 (v[0] + v[2])
                +2 * v[1];
        }
};
